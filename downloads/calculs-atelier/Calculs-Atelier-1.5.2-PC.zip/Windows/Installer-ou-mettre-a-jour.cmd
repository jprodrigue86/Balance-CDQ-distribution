@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
set "ATELIER_SOURCE=%~dp0"
set "ATELIER_DEST=%LOCALAPPDATA%\Programs\CalculsAtelier"
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\CalculsAtelier" /v InstallDir 2^>nul ^| findstr /i "InstallDir"') do set "ATELIER_DEST=%%B"
if not exist "%ATELIER_SOURCE%index.html" goto missing
if not exist "%ATELIER_SOURCE%Lancer.cmd" goto missing
if not exist "%ATELIER_SOURCE%app.ico" goto missing
echo.
echo Calculs d'atelier 1.5.2 - installation ou mise a jour
echo.
echo Enregistrez votre travail, puis fermez Calculs d'atelier.
echo Les donnees et le profil existants ne seront pas effaces.
echo Dossier utilise : %ATELIER_DEST%
echo.
pause
if not exist "%ATELIER_DEST%" mkdir "%ATELIER_DEST%"
if not exist "%ATELIER_DEST%" goto error
if exist "%ATELIER_DEST%\index.html" copy /y "%ATELIER_DEST%\index.html" "%ATELIER_DEST%\index.html.avant-1.5.2.bak" >nul
copy /y "%ATELIER_SOURCE%index.html" "%ATELIER_DEST%\index.html" >nul
if errorlevel 1 goto error
copy /y "%ATELIER_SOURCE%Lancer.cmd" "%ATELIER_DEST%\Lancer.cmd" >nul
if errorlevel 1 goto error
copy /y "%ATELIER_SOURCE%app.ico" "%ATELIER_DEST%\app.ico" >nul
if errorlevel 1 goto error
reg add "HKCU\Software\CalculsAtelier" /v InstallDir /t REG_SZ /d "%ATELIER_DEST%" /f >nul
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference='Stop'; $w=New-Object -ComObject WScript.Shell; foreach($base in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){$lnk=$w.CreateShortcut((Join-Path $base 'Calculs d atelier.lnk'));$lnk.TargetPath=Join-Path $env:ATELIER_DEST 'Lancer.cmd';$lnk.WorkingDirectory=$env:ATELIER_DEST;$lnk.IconLocation=Join-Path $env:ATELIER_DEST 'app.ico';$lnk.WindowStyle=7;$lnk.Save()}"
if errorlevel 1 echo Le raccourci n'a pas pu etre cree. Utilisez Lancer.cmd dans le dossier affiche.
echo.
echo Version 1.5.2 copiee. Le canal de mises a jour est deja configure.
start "" "%ATELIER_DEST%\Lancer.cmd"
exit /b 0
:missing
echo Archive incomplete. Extraire tout le dossier Windows avant de lancer ce fichier.
pause
exit /b 1
:error
echo Echec de copie. Ne supprimez pas vos donnees ni votre profil.
echo Fermez l'application et verifiez les droits sur le dossier.
pause
exit /b 1
