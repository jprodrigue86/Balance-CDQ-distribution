@echo off
setlocal
set "ATELIER_BROWSER="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "ATELIER_BROWSER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined ATELIER_BROWSER if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "ATELIER_BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined ATELIER_BROWSER if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" set "ATELIER_BROWSER=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
if not defined ATELIER_BROWSER if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "ATELIER_BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined ATELIER_BROWSER if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "ATELIER_BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined ATELIER_BROWSER if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "ATELIER_BROWSER=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined ATELIER_BROWSER (
  echo Microsoft Edge ou Google Chrome est necessaire pour ouvrir Calculs d'atelier.
  echo Installez l'un de ces navigateurs puis relancez l'application.
  pause
  exit /b 1
)
set "ATELIER_FILE=%~dp0index.html"
set "ATELIER_FILE=%ATELIER_FILE:\=/%"
start "" "%ATELIER_BROWSER%" --no-first-run --no-default-browser-check --user-data-dir="%LOCALAPPDATA%\CalculsAtelier\Profil" --app="file:///%ATELIER_FILE%"
exit /b 0
